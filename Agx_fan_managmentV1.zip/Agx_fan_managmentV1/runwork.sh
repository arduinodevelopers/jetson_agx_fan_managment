#!/bin/bash
python /home/drobotic/Desktop/Agx_fan_managmentV1/denme.py